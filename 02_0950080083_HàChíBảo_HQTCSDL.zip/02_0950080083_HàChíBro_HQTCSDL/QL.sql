﻿---Sau cùng, nhân viên QL xem lại kết quả NV1 và NV2 đã làm
select * from Person.PersonPhone where BusinessEntityID = 083
select * from Person.PersonPhone where BusinessEntityID = 095

--QL không thể xem dữ liệu trên bảng person.person vì nv 2 thuộc role datareader  có quyên trên các  bảng 
select * from Person.Person