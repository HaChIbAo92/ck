﻿---Nhân viên NV1 sửa số điện thoại của người có BusinessEntityID=(3 ký tự cuối của Mã SV của chính SV dự thi) thành 123-456-7890
select * from Person.PersonPhone where BusinessEntityID = 083

update Person.PersonPhone set PhoneNumber = '123-456-7890' where BusinessEntityID = 083

--Nv 1 không thể xem dữ liệu trên bảng person.person vì nv 1 thuộc role Nhanvien mà role Nhanvien chỉ có quyên trên bảng Person.PersonPhone
select * from Person.Person