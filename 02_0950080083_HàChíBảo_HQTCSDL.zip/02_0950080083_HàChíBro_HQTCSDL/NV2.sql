﻿---Nhân viên NV2 xóa số điện thoại của người có BusinessEntityID=(3 ký tự đầu của Mã SV của chính SV dự thi).
select * from Person.PersonPhone where BusinessEntityID = 095

delete Person.PersonPhone where BusinessEntityID = 095

--Nv 2 không thể xem dữ liệu trên bảng person.person vì nv 2 thuộc role Nhanvien mà role Nhanvien chỉ có quyên trên bảng Person.PersonPhone
select * from Person.Person