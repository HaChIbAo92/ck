﻿--Hà Chí Bảo_0950080083_09CNPM03
--Câu 1:
--a. Tạo các login và user cho các nhân viên:
-- Tạo login và user cho nhân viên NV 1
CREATE LOGIN NV11 WITH PASSWORD = 'password';
USE AdventureWorks2008R2;
CREATE USER NV11 FOR LOGIN NV11;
GRANT SELECT, INSERT, UPDATE, DELETE ON Person.PersonPhone TO NV11;

-- Tạo login và user cho nhân viên NV 2
CREATE LOGIN NV2 WITH PASSWORD = 'password';
USE AdventureWorks2008R2;
CREATE USER NV2 FOR LOGIN NV2;
GRANT SELECT, INSERT, UPDATE, DELETE ON Person.PersonPhone TO NV2;

-- Tạo login và user cho nhân viên quản lý
CREATE LOGIN QL1 WITH PASSWORD = 'password';
USE AdventureWorks2008R2;
CREATE USER QL1 FOR LOGIN QL1;
GRANT SELECT ON Person.PersonPhone TO QL1;
GRANT SELECT ON Person.Person TO QL1;


--b.Tạo role NhanVien, phân quyền cho role, thêm các user NV1, NV2, QL vào các role theo phân công ở trên để các nhân viên hoàn thành nhiệm vụ (1đ).
CREATE ROLE NhanVien1;
GRANT SELECT, INSERT, UPDATE, DELETE 
TO NhanVien1;
ALTER ROLE NhanVien1
ADD MEMBER NV11;
ALTER ROLE NhanVien1
ADD MEMBER NV2;
ALTER ROLE db_datareader
ADD MEMBER QL1;


--d. Ai có thể xem dữ liệu bảng Person.Person? Giải thích. Viết lệnh kiểm tra quyền trên cửa sổ query của user tương ứng (1đ).


--e)e. Các nhân viên quản lý NV1, NV2, QL hoàn thành dự án, admin thu hồi quyền đã cấp. Xóa role NhanVien. (1đ).
alter role NhanVien1
drop member NV11
alter role NhanVien1
drop member NV2
ALTER ROLE db_datareader
drop MEMBER QL1;

drop role Nhanvien1


--Câu 2:
--a/a. Tạo một giao tác tăng lương (Rate) thêm 20% cho các nhân viên làm việc ở phòng (Department.Name) ‘Production’ và ‘Production Control’. Tăng lương 15% cho các nhân viên các phòng ban khác. [Ghi nhận dữ liệu đang có và Viết lệnh Full Backup]. (1đ)
alter  database AdventureWorks2008R2
set recovery full
backup database AdventureWorks2008R2
to disk = 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL\MSSQL\Backup\adventure-works-2008r2-oltp.bak'

--b. Xóa mọi bản ghi trong bảng PurchaseOrderDetail. [Viết lệnh Differential Backup] (1đ).
delete Purchasing.PurchaseOrderDetail
backup database AdventureWorks2008R2
to disk = 'C:\Program Files\Microsoft SQL Server\MSSQL12.SQL\MSSQL\Backup\adventure-works-2008r2-oltp.bak'
with differential 

--c. Bổ sung thêm 1 số phone mới (Person.PersonPhone) tùy ý cho nhân viên có mã số nhân viên (BusinessEntityID) là 4 ký tự cuối của Mã SV của chính SV dự thi, ModifiedDate=getdate(). [Ghi nhận dữ liệu đang có và Viết lệnh Log Backup] (1đ).
select * from Person.PersonPhone where BusinessEntityID = 0083

update Person.PersonPhone set PhoneNumber = '123-456-7890' where BusinessEntityID = 0083
--d. Xóa CSDL AdventureWorks2008R2. Phục hồi CSDL về trạng thái sau khi thực hiện bước c. Kiểm tra xem dữ liệu phục hồi có đạt yêu cầu không (lương có tăng, các bản ghi có bị xóa, có thêm số phone mới)? (1đ)